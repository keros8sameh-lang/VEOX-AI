import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
import crypto from "node:crypto";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const jobs = new Map();
const allowedDurations = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    app: "Video AI Studio",
    mode: process.env.VIDEO_API_URL && process.env.VIDEO_API_KEY ? "provider-configured" : "demo",
    message: process.env.VIDEO_API_URL && process.env.VIDEO_API_KEY
      ? "Provider credentials are configured; confirm provider-specific request mapping before production use."
      : "Demo mode: no real video generation provider is connected yet."
  });
});

app.post("/api/videos", async (req, res) => {
  const { prompt, style = "cinematic", aspectRatio = "16:9", duration = 1, language = "ar", quality = "standard" } = req.body || {};

  if (typeof prompt !== "string" || prompt.trim().length < 8) {
    return res.status(400).json({ error: "اكتب وصفًا للفيديو لا يقل عن 8 أحرف." });
  }
  if (prompt.length > 3000) return res.status(400).json({ error: "الوصف طويل جدًا؛ الحد الأقصى 3000 حرف." });
  if (!allowedDurations.includes(Number(duration))) return res.status(400).json({ error: "اختر مدة من دقيقة إلى 10 دقائق." });

  // This safe starter intentionally does not guess a provider's API format.
  // Video generation APIs differ, so the provider-specific adapter must be implemented
  // after the user chooses a provider and supplies its server-side credentials.
  const id = crypto.randomUUID();
  const configured = Boolean(process.env.VIDEO_API_URL && process.env.VIDEO_API_KEY);

  const job = {
    id,
    prompt: prompt.trim(),
    style,
    aspectRatio,
    duration: Number(duration),
    language,
    quality,
    status: "waiting_for_provider",
    mode: "demo",
    createdAt: new Date().toISOString(),
    message: configured
      ? "معلومات الخدمة موجودة، لكن يلزم إعداد موصل API الخاص بمزوّد الفيديو قبل التوليد الحقيقي."
      : "تم حفظ طلبك التجريبي. لبدء توليد فيديو حقيقي، اربط خدمة توليد فيديو لاحقًا."
  };
  jobs.set(id, job);
  return res.status(202).json(job);
});

app.get("/api/videos/:id", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "لم يتم العثور على هذا الطلب." });
  res.json(job);
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`Video AI Studio running on port ${PORT}`));
